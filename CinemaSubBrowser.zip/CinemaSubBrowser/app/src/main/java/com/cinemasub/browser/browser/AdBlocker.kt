package com.cinemasub.browser.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {

    private val emptyResponseBytes = ByteArray(0)

    private val blockedHosts: Set<String> = hashSetOf(
        "doubleclick.net",
        "googleadservices.com",
        "googlesyndication.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "google-analytics.com",
        "googletagmanager.com",
        "ads.youtube.com",
        "adnxs.com",
        "adsrvr.org",
        "advertising.com",
        "amazon-adsystem.com",
        "criteo.com",
        "criteo.net",
        "outbrain.com",
        "taboola.com",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "casalemedia.com",
        "scorecardresearch.com",
        "quantserve.com",
        "moatads.com",
        "doubleverify.com",
        "adcolony.com",
        "applovin.com",
        "unityads.unity3d.com",
        "vungle.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "mgid.com",
        "revcontent.com",
        "zedo.com",
        "spotxchange.com",
        "imasdk.googleapis.com"
    )

    private val blockedUrlPatterns = listOf(
        "/pagead/",
        "/ptracking",
        "/api/stats/ads",
        "ad_type=",
        "doubleclick",
        "googlesyndication",
        "popunder"
    )

    fun isAd(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false

        var currentHost = host
        while (currentHost.contains('.')) {
            if (currentHost in blockedHosts) return true
            currentHost = currentHost.substringAfter('.')
        }

        val lowerUrl = url.lowercase()
        return blockedUrlPatterns.any { lowerUrl.contains(it) }
    }

    fun createEmptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(emptyResponseBytes))
}
