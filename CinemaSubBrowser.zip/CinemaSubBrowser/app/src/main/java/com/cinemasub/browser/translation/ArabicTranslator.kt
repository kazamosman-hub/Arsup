package com.cinemasub.browser.translation

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await
import java.util.concurrent.atomic.AtomicBoolean

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val translator: Translator = Translation.getClient(options)
    private val isReady = AtomicBoolean(false)

    suspend fun ensureModelDownloaded() {
        if (isReady.get()) return
        val conditions = DownloadConditions.Builder().build()
        translator.downloadModelIfNeeded(conditions).await()
        isReady.set(true)
    }

    suspend fun translateToArabic(englishText: String): String {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) return ""
        if (!isReady.get()) ensureModelDownloaded()
        return runCatching {
            translator.translate(cleaned).await()
        }.getOrDefault("")
    }

    fun close() {
        translator.close()
    }
}
