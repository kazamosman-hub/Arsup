# Keep Vosk and ML Kit classes
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keep class com.google.mlkit.** { *; }
