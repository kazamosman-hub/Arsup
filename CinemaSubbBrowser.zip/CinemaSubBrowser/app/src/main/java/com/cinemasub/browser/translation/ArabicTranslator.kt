package com.cinemasub.browser.translation

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    suspend fun translateToArabic(englishText: String): String {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) return ""

        val onlineResult = translateViaGoogleFree(cleaned)
        if (!onlineResult.isNullOrBlank()) {
            return onlineResult
        }

        if (!isOfflineReady.get()) ensureModelDownloaded()
        return runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault("")
    }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                sb.append(part)
            }
            sb.toString().trim()
        }.getOrNull()
    }

    fun close() {
        mlKitTranslator.close()
    }
}
